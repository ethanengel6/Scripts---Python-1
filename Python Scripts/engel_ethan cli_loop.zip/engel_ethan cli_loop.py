

for q in range (1,len(sys.argv)):
  print(argv[q])
