import unittest

def testMax(self):
  ret=max([1,3,4,9])
  self.assertEqual(ret,9)
